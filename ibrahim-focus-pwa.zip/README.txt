رفع التطبيق على GitHub Pages
1) أنشئ حسابًا على github.com ثم New repository باسم مثل focus (Public).
2) Add file ← Upload files، وارفع كل محتويات هذا المجلد (index.html و sw.js و manifest.json والأيقونات و tips.txt ومجلد .github) ثم Commit.
3) Settings ← Pages ← Source: Deploy from a branch ← main ← / (root) ← Save.
4) بعد دقيقة افتح https://اسمك.github.io/focus/ في Chrome ← ⋮ ← تثبيت التطبيق / إضافة إلى الشاشة الرئيسية.
5) افتح التطبيق مرة واحدة بإنترنت، ثم يعمل بدونه. من تقدمي ← فعّل الإشعارات.
6) استورد آخر نسخة احتياطية من تقدمي ← البيانات.

إشعارات والتطبيق مغلق (اختياري، مجاني):
أ) ثبّت تطبيق ntfy من متجر التطبيقات، واشترك في موضوع اسمه سري طويل مثل ibrahim-7f3k9x2m.
ب) في GitHub: Settings ← Secrets and variables ← Actions ← New secret باسم NTFY_TOPIC وقيمته اسم الموضوع.
ج) تصلك رسائل تحفيز وتذكير 5 مرات يوميًا (9 و12 و3 و6 و9 بتوقيت القاهرة شتاءً؛ ساعة أبكر صيفًا).
عند تعديل index.html غيّر رقم ibf-v1 في sw.js ليتحدث التطبيق.
